using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Practica_12.Models;

namespace Practica_12.Controllers
{
    public class AreaController : Controller
    {
        private readonly ILogger<AreaController> _logger;

        public AreaController(ILogger<AreaController> logger)
        {
            _logger = logger;
        }

        public IActionResult Area()
        {
            return View();
        }
        private const int V = 2;
        [HttpPost]
        public ActionResult Area(string bas, string altura, string tip)
        {
            int x = Convert.ToInt32(bas);
            int y = Convert.ToInt32(altura);
            int z = 0;
            int t = 0;
            if(tip=="Triangulo")
            {
                t=x*y;
                z=t/V;
                ViewBag.Result = z;
            }
            else{
                ViewBag.Result = z;
            }
            if(tip=="Rectangulo")
            {
                z=x*y;
                ViewBag.Result = z;
            }
            else{
                ViewBag.Result = z;
            }
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }    
}